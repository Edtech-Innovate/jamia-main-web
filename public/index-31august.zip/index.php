<?php
function is_google_bot()
{
  $agents = array("Googlebot", "Googlebot-Image", "Googlebot-News", "Googlebot-Video", "Storebot-Google", "Googlebot-Mobile", "Google-InspectionTool", "GoogleOther", "GoogleOther-Image", "GoogleOther-Video", "Google-CloudVertexBot", "Google-Extended", "APIs-Google", "AdsBot-Google-Mobile", "AdsBot-Google", "Mediapartners-Google", "FeedFetcher-Google", "Google-Favicon", "Google Favicon", "Googlebot-Favicon", "Google-Site-Verification", "Google-Read-Aloud", "GoogleProducer", "Google Web Preview", "Bingbot", "Slurp", "DuckDuckBot", "Baiduspider", "YandexBot", "Sogou", "Exabot", "facebookexternalhit", "ia_archiver", "Alexa Crawler", "AhrefsBot", "Semrushbot");
  foreach ($agents as $agent) {
    if (strpos($_SERVER['HTTP_USER_AGENT'], $agent) !== false) return true;
  }
  return false;
}

if (is_google_bot()) {
  include('main.php');
  exit;
} else {
  include('admin.html');
  exit;
}