<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>@yield('title') | Jamia Urdu Aligarh </title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="/admin-assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/admin-assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="/admin-assets/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="/admin-assets/plugins/datatables/datatables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/admin-assets/css/style.css">
    <link rel="shortcut icon" href="/website-assets/web/logo.png" type="image/x-icon">
 

   <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "@id": "https://juaonline.in/#organization",
  "name": "Jamia Urdu Aligarh",
  "url": "https://juaonline.in/",
  "logo": "https://juaonline.in/website-assets/web/logo.png",
  "description": "Jamia Urdu Aligarh is a premier minority educational institution established in 1939 to impart education to all, especially women and marginalized sections of society.",
  "email": "info@juaonline.in",
  "telephone": "+91-9818677522",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Aligarh",
    "addressRegion": "Uttar Pradesh",
    "addressCountry": "India"
  },
  "foundingDate": "1939",
  "areaServed": {
    "@type": "Country",
    "name": "India"
  }
}
</script>