<section class=" shape-mockup-wrap bg-smoke ">
   <div class="space overflow-hidden" id="about-sec">
      <div class="container">

         <div class="row m-auto justify-content-center align-items-center ">

            <div class="col-md-6 mb-0">
               <div class="title-area mb-0 ">
                  <h1 class="h2 sec-title text-dark">About Jamia Urdu Aligarh</h1>



                  <p class=" text-white align-justify mt-md-3  ">Jamia Urdu Aligarh is one of the premier minority educational institutions in India granted by
                     the National Commission for Minority Education Institution (NCMEI); Established
                     in 1939 to educate the most disadvantaged sections of the society. With a mission to promote urdu language and impart quality education to the women and marginalized section of the society, Jamia Urdu Aligarh is educating the masses through its various courses. Many Government
                     institutions, Boards, Universities and educational Institutions recognise the courses
                     of Jamia Urdu Aligarh, which are consider equivalent to the certification of the
                     respective State Boards.
                  </p>
               </div>
            </div>
            <div class="col-md-6">
               <div class="">
                  <div class="img1">
                     <img class="" src="/website-assets/web/approval-slider-2.webp" alt="About jamia" width="624" height="350" loading="lazy">
                     <!-- <img class="img-fluid" src="/website-assets/web/approval-slider1.webp" alt="Recognization & Approval" width="300" height="300" loading="lazy"> -->


                  </div>
                  <!-- <div class="about-grid" data-bg-src="/website-assets/img/normal/about_1_3.png">
                        <h3 class="about-grid_year"><span class="counter-number">10</span>k<span class="text-theme">+</span></h3>
                        <p class="about-grid_text">Students Active Our Courses</p>
                     </div>  -->
               </div>
            </div>

            <!-- <div class="col-md-6 card  about-bg">
               <div class="row g-1 text-center card-body py-4 ">
                  <div class="col-12 col-md-12 mb-3">
                     <div class=" text-start ">
                        <span class="about_name text-dark">Name: JAMIA URDU ALIGARH</span>
                     </div>
                  </div>
                  <div class="col-12 col-md-12 mb-3">
                     <div class="  text-start">
                        <span class="about_name text-dark">Established: 1939</span>
                     </div>
                  </div>


                  <div class="col-12 col-md-12 mb-3">
                     <div class="text-start ">
                        <span class="about_name text-dark">Region: Uttar Pradesh</span>
                     </div>
                  </div>

                  <div class="col-12 col-md-12 mb-3">
                     <div class="  text-start ">
                        <span class="about_name text-dark">Official language: Urdu</span>
                     </div>
                  </div>

                  <div class="col-12 col-md-12 mb-3">
                     <div class="  text-start ">
                        <span class="about_name text-dark">Parent organization: Jamia Urdu Aligarh</span>
                     </div>
                  </div>
                  <div class="col-12 col-md-12 mb-3">
                     <div class=" text-start">
                        <span class="about_name text-dark">Website: <a href="https://juaonline.in/" class="text-dark" target="_blank">juaonline.in</a><span> , </span> <a href="https://info@jamiaurdualigarh.com/" class="text-dark" target="_blank">info@Jamiaurdualigarh.com</a></span>
                     </div>
                  </div>
                  <div class="col-12 col-md-12 ">
                     <div class=" text-start ">
                        <span class="about_name text-dark">Headquarters : JAMIA URDU ALIGARH, Dodhpur, Civil Lines, Aligarh, Uttar Pradesh, 202002 </span>
                     </div>
                  </div>

               </div>
            </div>
            <div class="mt-3">
               <div class="card card-body border-2 about-bg p-3">
                  <p class="text-dark pt-2">The courses of Jamia Urdu Aligarh are recognized by Government of India, by
                     the office Memorandum No. 14021 / 2 / 78-Estt. (D) dated 28 June 1978 of Ministry
                     of Home Affairs / Home Ministry (Department of Personnel and Administrative
                     Reforms).</p>

                  <ul class="text-dark">
                     <li>Member of COBSE</li>
                     <li>Website Link : <a class="text-white" href="http://www.cobse.in">www.cobse.in</a></li>
                     <li>Granted by NCMEI (National Commission for Minority Educational Institutions, India)</li>
                     <li>Approved by NATIONAL COUNCIL FOR PROMOTION OF URDU LANGUAGE</li>
                  </ul>
                  <div class="btn-group justify-content-end "><a href="/about" class="th-btn bg-dark ">About More<i class="fa-regular fa-arrow-right ms-2"></i></a></div>

               </div>
            </div> -->




             <div class="col-md-6 mt-md-4 mt-3">

               <div class="card card-body border-2 about-bg p-3">
                  <p class="text-dark pt-2">The courses of Jamia Urdu Aligarh are recognized by Government of India, by
                     the office Memorandum No. 14021 / 2 / 78-Estt. (D) dated 28 June 1978 of Ministry
                     of Home Affairs / Home Ministry (Department of Personnel and Administrative
                     Reforms).</p>
                     <div class="checklist style3 mb-45">
                  <ul class="text-dark about_approved_icon_ist ">
                     <li  class="text-dark about_icon_color pb-0">Member of COBSE</li>
                     <li  class="text-dark about_icon_color pb-0">Website Link : <a class="text-dark" href="http://www.cobse.in">www.cobse.in</a></li>
                     <li  class="text-dark about_icon_color pb-0">Granted by NCMEI (National Commission for Minority Educational Institutions, India)</li>
                     <li  class="text-dark about_icon_color pb-0">Approved by NATIONAL COUNCIL FOR PROMOTION OF URDU LANGUAGE</li>
                  </ul>
                     </div>
                  <!-- <div class="btn-group justify-content-end "><a href="/about" class="th-btn bg-dark ">About More<i class="fa-regular fa-arrow-right ms-2"></i></a></div> -->


               </div>
            </div>
            <div class="col-md-6 mt-md-4 mb-4 mt-4 mt-md-5">
               <div class="card card-body border-2 about-bg px-md-3 py-md-4">
                  <ul class="about_approved_icon_ist">
                     <li data-marker-icon="&#xf007" class="text-dark about_icon_color"> <span class="mt-2">Name: JAMIA URDU ALIGARH </span> </li>
                     <li data-marker-icon="&#xf073" class="text-dark about_icon_color1"> <span class="mt-2">Established: 1939 </span></li>
                     <li data-marker-icon="&#xf3c5" class="text-dark about_icon_color2"> <span class="mt-2">Region: Uttar Pradesh </span></li>
                     <li data-marker-icon="&#xf1ab" class="text-dark about_icon_color3"> <span class="mt-2">Official language: Urdu </span></li>
                     <li data-marker-icon="&#xf1ad" class="text-dark about_icon_color4"> <span class="mt-2">Parent organization: Jamia Urdu Aligarh </span></li>
                     <li data-marker-icon="&#xf0ac" class="text-dark about_icon_color5"> <span class="mt-2">Website: <a href="https://juaonline.in/" class="text-dark" target="_blank">juaonline.in</a><span> , </span> <a href="https://info@jamiaurdualigarh.com/" class="text-dark" target="_blank">info@Jamiaurdualigarh.com</a></span> </span></li>
                     <li data-marker-icon="&#xe0cc" class="text-dark about_icon_color6"> <span class="mt-2">Headquarters : JAMIA URDU ALIGARH, Dodhpur, Civil Lines, Aligarh, Uttar Pradesh, 202002 </span></li>

                  </ul>
               </div>
            </div> 


         </div>
      </div>

   </div>
   <!-- <div class="shape-mockup d-none d-md-block" data-top="0%" data-left="0%"><img src="/website-assets/img/update1/shape/shadow_1.png" alt="shapes"></div> -->
</section>