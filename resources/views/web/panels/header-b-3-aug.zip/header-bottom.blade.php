</head>

<body>
   <div class="th-menu-wrapper ">
      <div class="th-menu-area text-center">
         <button class="th-menu-toggle"><i class="fal fa-times"></i></button>
         <div class="mobile-logo"><a href="/"><img src="/website-assets/web/logo.png" alt="JUA" loading="lazy" width="400" height="88"></a></div>
         <div class="th-mobile-menu">
            <ul>
               <li class="menu-item-has-children">
                  <a href="#">Programs</a>
                  <ul class="sub-menu">
                     <li><a href="/10th-adeeb-secondary">10<sup>th</sup>/ADEEB/SECONDARY</a></li>
                     <li><a href="/12th-adeeb-e-mahir-secondary">12<sup>th</sup>/ADEEB-E-MAHIR/SENIOR SECONDARY</a></li>
                     <!-- <li><a href="/fee-structure">Fee Structure</a></li> -->
                  </ul>
               </li>
               <li class="menu-item-has-children">
                  <a href="/about">About Us</a>
                  <ul class="sub-menu">
                     <li><a href="/about">About University</a></li>
                     <li><a href="/vision-mission">Vision Mission</a></li>
                     <li><a href="#">Committee</a></li>
                     <li><a href="#">Facilities</a></li>
                     <li class="menu-item-has-children">
                        <a href="#">Messages</a>
                        <ul class="sub-menu">
                           <li><a href="/registrar">Registrar</a></li>
                           <li><a href="/vice-cancellor">Vice Chancellor</a></li>
                           <li><a href="/controller-of-exam">Controller of Exam</a></li>
                           <li><a href="/osd">OSD</a></li>

                        </ul>
                     </li>
                  </ul>
               </li>
               <li class="menu-item-has-children">
                  <a href="#">Examination</a>
                  <ul class="sub-menu">
                     <!-- <li><a href="#">Download Exam Form</a></li> -->
                     <li><a href="#">Exam Time Table</a></li>
                     <li><a href="/general-guidlines">General Guidelines</a></li>
                     <!-- <li><a href="#">Document Application Form</a></li> -->
                     <!--<li><a href="https://www.jamiaurdualigarh.com/result-online/" target="_blank">Online result</a></li>-->
                  <li><a href="/student-login" target="_blank">Online result</a></li>
                 
                  </ul>
               </li>
               </li>
               <li class="menu-item-has-children">
                  <a href="/approvals"><span class="new-badge " style="position: relative;top: -8px;">New</span> Approvals</a>

               </li>
               <!-- <li class="menu-item-has-children">
                  <a href="/blogs">BLOGS</a>
                  <ul class="sub-menu">
                     <li><a href="/blogs">Blogs</a></li>
                     <li><a href="/blog-details">Blogs Details</a></li>
                  </ul>
               </li> -->
               <li class="menu-item-has-children">
                  <a href="#">Information Guidance Centers</a>
                  <ul class="">
                     <li><a href="/authorized-centers">Authorized Centers</a>
                        <ul class="">
                           <li><a href="/centers/india">India</a></li>
                           <li><a href="/overseas">Overseas</a></li>

                        </ul>
                     </li>
                     <li><a href="/online-information">Apply for Center</a>
                        <ul class="">
                           <li><a href="/new_center">Online</a></li>
                           <li><a href="website-assets/offine_jamia.pdf" target="_blank">Offline</a></li>

                        </ul>
                        <!-- </li>
                                    <li><a href="#">Offline Information</a></li> -->
                  </ul>
               </li>
               <li><a href="/contact">Contact Us</a></li>
            </ul>



            </ul>
         </div>
      </div>
   </div>
   <div class="popup-search-box d-none d-lg-block">
      <button class="searchClose"><i class="fal fa-times"></i></button>
      <form action="#"><input type="text" placeholder="What are you looking for?"> <button type="submit"><i class="fal fa-search"></i></button></form>
   </div>