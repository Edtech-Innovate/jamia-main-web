<style>
    .header-layout1 .header-top {
        background: black !important;
    }
</style>
<header class="th-header header-layout1">
   <div class="header-top">
      <div class="container">
         <div class="row justify-content-center justify-content-lg-between align-items-center gy-2">
            <div class="col-auto d-none d-lg-block">
               <div class="header-links">
                  <ul>
                     <li><i class="far fa-phone"></i><a href="tel:9818677522" >+91 9818677522</a>
                     <!--<span>,<a href="tel:9821786970">+91 9821786970</a>,<a href="tel:9773651913">+91 9773651913</a>-->
                  </li>
                     <li class="d-none d-xl-inline-block"><i class="far fa-envelope"></i>
                        <a href="mailto:info@jamiaurdualigarh.com">info@juaonline.in</a>
                     </li>
                  </ul>
               </div>
            </div>
            <div class="col-auto">
               <div class="header-links header-right text-center">
                  <ul>
                     <li>
                        <div class="header-social"><span class="social-title">Follow Us:</span> <a href="https://www.facebook.com/JamiaUrduUniversity" aria-label="facbook link" target="_blank"><i class="fab fa-facebook-f"></i></a> <a href="https://www.instagram.com/jamia_urdu_online/" aria-label="instagram" target="_blank"><i class="fab fa-instagram"></i></a> <a href="https://www.linkedin.com/company/jamia-urdu-aligarh-online" aria-label="linkdin link" target="_blank"><i class="fab fa-linkedin-in"></i></a> </div>
                     </li>
                     <li class="d-block d-lg-inline-block mt-2">
                        <!--<i class="far fa-user"></i><a href="https://board.juaonline.in/" target="_blank"><span class="e-btn text-capitalize">Login / Register</span></a>-->
                        <i class="far fa-user"></i><a href="https://board.juaonline.in/" target="_blank"><span class="e-btn text-capitalize">Login</span></a>

                        <!-- Modal -->

                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="sticky-wrapper">
      <div class="menu-area">
         <div class="container">
            <div class="row align-items-center justify-content-between">
               <div class="col-auto">
                  <div class="header-logo">
                     <a href="/"> <img src="/website-assets/web/jamai-logos.webp" width="200" height="60" loading="lazy" alt="Jamia Urdu Aligarh Logo" class="logo-website" alt="Jamia Urdu"></a>
                     <!-- <img src="assets/web/azadi-ka-amrit.png" width="120" alt="Jamia Urdu"> -->
                  </div>
               </div>
               <div class="col-auto">
                  <div class="row">
                     <div class="col-auto">
                        <nav class="main-menu d-none d-lg-inline-block">
                           <ul>

                              <li class="menu-item-has-children">
                                 <a href="#">Programs</a>
                                 <ul class="sub-menu">
                                    <li><a href="/10th-adeeb-secondary">10<sup>th</sup>/ADEEB/High School (Secondary Level)</a></li>
                                    <li><a href="/12th-adeeb-e-mahir-secondary">12<sup>th</sup>/ADEEB-E-MAHIR/Intermediate (Senior Secondary Level)</a></li>
                                    <!-- <li><a href="#">IBTEDAI</a></li>
                                     <li><a href="#">ADEEB-E- KAMIL</a></li>
                                     <li><a href="#">MOALLIM-E-URDU</a></li>
                                     <li><a href="#">ADEEB-E-FAZIL</a></li>
                                     <li><a href="#">DIPLOMA IN JOURNALISM & MASS COMMUNICATION</a></li> -->
                                    <!-- <li><a href="/fee-structure">Fee Structure</a></li> -->
                                 </ul>
                              </li>

                              <li class="menu-item-has-children">
                                 <a href="/about">About Us</a>
                                 <ul class="sub-menu">
                                    <li><a href="/about">About Jamia</a></li>
                                    <li><a href="/vision-mission">Vision Mission</a></li>
                                    <li><a href="#">Committee</a></li>
                                    <li><a href="#">Facilities</a></li>
                                    <li class="menu-item-has-children">
                                       <a href="#">Messages</a>
                                       <ul class="sub-menu">
                                          <li><a href="/registrar">Registrar</a></li>
                                          <li><a href="/vice-cancellor">Vice Chancellor</a></li>
                                          <li><a href="/controller-of-exam">Controller of Exam</a></li>
                                          <li><a href="/osd">OSD</a></li>

                                       </ul>
                                    </li>
                                 </ul>
                              </li>


                              <li class="menu-item-has-children">
                                 <a href="#">Examination</a>
                                 <ul class="sub-menu">
                                    <!-- <li><a href="#">Download Exam Form</a></li> -->
                                    <li><a href="#">Exam Time Table</a></li>
                                    <li><a href="/general-guidlines">General Guidelines</a></li>
                                    <!-- <li><a href="#">Document Application Form</a></li> -->
                                    <li><a href="/student-login" >Online result</a></li>
                                   <li><a href="/website-assets/AcademicCalender2025-Februaryjuaonline.pdf"  target="_blank">Academic Calender</a></li>

                                 </ul>
                              </li>
                              <li><a href="/approvals"><span class="new-badge " style="position: relative;top: -8px;">New</span> Approvals</a></li>

                              <!-- <li><a href="/blogs">Blogs</a></li>
                              </li> -->
                              <li class="menu-item-has-children"><a href="#">Information Guidance Centers</a>
                                 <ul class="sub-menu">
                                    <li><a href="/authorized-centers">Authorized Centers</a>
                                       <ul class="sub-menu">
                                          <li><a href="/centers/india">India</a></li>
                                          <li><a href="/centers/overseas">Overseas</a></li>

                                       </ul>
                                    </li>
                                    <!-- <li><a href="/online-information">Online Information</a></li>
                                    <li><a href="#">Offline Information</a></li> -->
                                    <li><a href="#">Apply for Center</a>
                                       <ul class="sub-menu">
                                          <li><a href="/new_center">Online</a></li>
                                          <li><a href="website-assets/offine_jamia.pdf" target="_blank">Offline</a></li>

                                       </ul>
                                    </li>

                                 </ul>
                              </li>
                              <li><a href="/contact">Contact Us</a></li>
                           <li ><a href="/website-assets/web/prospectus.pdf" class="text-warning btn btn-outline-warning p-1" target="_blank" style="text-transform:none;"  download="Jamia-Prospectus.pdf"> Prospectus</a></li>

                           </ul>
                        </nav>
                        <button type="button" class="th-menu-toggle d-block d-lg-none " aria-label="mobile-menu"><i class="far fa-bars "></i></button>
                     </div>
                     <!-- <div class="col-auto d-none d-xl-block">
                         <div class="header-button"><button type="button" class="icon-btn searchBoxToggler"><i class="far fa-search"></i></button>
                           <a href="contact.html" class="th-btn ml-25">Contact Us <i class="fas fa-arrow-right ms-1"></i></a>
                       </div>
                      </div> -->
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</header>