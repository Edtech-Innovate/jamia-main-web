<footer class="footer-wrapper footer-layout1">
    <!--<div class="shape-mockup footer-shape1 jump" data-left="60px" data-top="70px"><img src="/website-assets/img/normal/footer-bg-shape1.png" alt="img"></div>-->
    <!--<div class="shape-mockup footer-shape2 jump-reverse" data-right="80px" data-bottom="120px"><img src="/website-assets/img/normal/footer-bg-shape2.png" alt="img"></div>-->
    <div class="footer-top">
       <div class="container">
          <div class="footer-contact-wrap">
             <div class="footer-contact">
                <div class="footer-contact_icon icon-btn"><i class="fal fa-phone"></i></div>
                <div class="media-body">
                   <p class="footer-contact_text">Call us any time:</p>
                   <a href="tel:" class="footer-contact_link">+91 9818677522,</a>
                    <a href="tel:" class="footer-contact_link">+91 9821786970</a>
                     <a href="tel:" class="footer-contact_link">+91 9773651913</a>
                </div>
             </div>
             <div class="divider"></div>
             <div class="footer-contact">
                <div class="footer-contact_icon icon-btn"><i class="fal fa-envelope"></i></div>
                <div class="media-body">
                   <p class="footer-contact_text">Email us 24/7 hours:</p>
                   <a href="mailto:info@juaonline.in" class="footer-contact_link">info@juaonline.in</a>
                </div>
             </div>
             <div class="divider"></div>
             <div class="footer-contact">
                <div class="footer-contact_icon icon-btn"><i class="fal fa-location-dot"></i></div>
                <div class="media-body">
                   <p class="footer-contact_text">Location:</p>
                   <a href="#" class="footer-contact_link">Dodhpur, Civil LinesAligarh 202002 UP India</a>
                </div>
             </div>
          </div>
       </div>
    </div>
    <div class="footer-wrap" data-bg-src="/website-assets/img/bg/jiji.png">
       <div class="widget-area">
          <div class="container">
             <div class="row justify-content-between">
                <div class="col-md-6 col-xxl-3 col-xl-3">
                   <div class="widget footer-widget">
                      <div class="th-widget-about">
                         <div class="about-logo"><a href="index.php"><img src="/website-assets/web/logow.png" alt="jmu"></a></div>
                         <p class="about-text">Sir Syed Ahmad Khan and his associates had established only a College but their Aligarh Movement lighted a lamp of education and knowledge.</p>
                         <div class="th-social">
                            <h6 class="title text-white">FOLLOW US ON:</h6>
                            <a href="https://www.facebook.com/JamiaUrduUniversity"><i class="fab fa-facebook-f"></i></a>
                             <!--<a href="#"><i class="fab fa-twitter"></i></a>-->
                             <a href="https://www.instagram.com/jamia_urdu_online/"><i class="fab fa-instagram"></i></a>
                              <a href="https://www.linkedin.com/company/jamia-urdu-aligarh-online"><i class="fab fa-linkedin-in"></i></a>
                             
                         </div>
                      </div>
                   </div>
                </div>
                <div class="col-md-6 col-xl-auto">
                   <div class="widget widget_nav_menu footer-widget">
                      <h3 class="widget_title">Quick Links</h3>
                      <div class="menu-all-pages-container">
                         <ul class="menu">
                            <li><a href="/about">About Us</a></li>
                            <li><a href="/vision-mission">Vision Mission</a></li>
                            <!--<li><a href="/committee">Committee</a></li>-->
                            <!--<li><a href="#">Facilities</a></li>-->
                            <!--<li><a href="/fee-structure">Fee Structure</a></li>-->
                            <li><a href="/approvals">Approvals</a></li>
                            <li><a href="/blogs">Blog</a></li>
                                                        <li><a href="/payment_form">Quick Pay</a></li>

                         </ul>
                      </div>
                   </div>
                </div>
                <div class="col-md-6 col-xl-auto">
                   <div class="widget widget_nav_menu footer-widget">
                      <h3 class="widget_title">Programmes</h3>
                      <div class="menu-all-pages-container">
                         <ul class="menu">
                            <li><a href="/10th-adeeb-secondary">10<sup>th</sup>ADEEB/SECONDARY</a></li>
                            <li><a href="/12th-adeeb-e-mahir-secondary">12<sup>th</sup>/ADEEB-E-MAHIR/SENIOR SECONDARY</a></li>
                            <!-- <li><a href="#">IBTEDAI</a></li>
                            <li><a href="#">ADEEB-E- KAMIL</a></li>
                            <li><a href="#">MOALLIM-E-URDU</a></li>
                            <li><a href="#">ADEEB-E-FAZIL</a></li>
                            <li><a href="#">DIPLOMA IN JOURNALISM & MASS COMMUNICATION</a></li> -->
                         </ul>
                      </div>
                   </div>
                </div>
                <!--<div class="col-md-6 col-xxl-3 col-xl-3">-->
                <!--   <div class="widget newsletter-widget footer-widget">-->
                <!--      <h3 class="widget_title">Apply Now!</h3>-->
                <!--      <form class="newsletter-form form-group">-->
                <!--         <input class="form-control mb-2" type="email" placeholder="Name" required=""> <i class="far fa-user"></i>-->
                <!--         <input class="form-control mb-2" type="email" placeholder="Phone" required=""> <i class="far fa-envelope"></i>-->
                <!--         <input class="form-control mb-2" type="email" placeholder="Email" required=""> <i class="far fa-phone"></i>-->
                <!--         <select name="" id="" class="form-control mb-2">-->
                <!--            <option>Choose Programm</option>-->
                <!--            <option>10<sup>th</sup>ADEEB/SECONDARY</option>-->
                <!--            <option>12<sup>th</sup>/ADEEB-E-MAHIR/SENIOR SECONDARY</option>-->
                            <!-- <option>IBTEDAI</option>
                <!--            <option>ADEEB-E- KAMIL</option>-->
                <!--            <option>MOALLIM-E-URDU</option>-->
                <!--            <option>ADEEB-E-FAZIL</option>-->
                <!--            <option>DIPLOMA IN JOURNALISM & MASS COMMUNICATION</option> -->-->
                <!--         </select>-->
                <!--         <button type="button" class="th-btn style3">Apply Now <i class="far fa-arrow-right ms-1"></i></button></form>-->
                <!--   </div>-->
                <!--</div>-->
             </div>
          </div>
       </div>
       <div class="container">
          <div class="copyright-wrap">
             <div class="row justify-content-between align-items-center">
                <div class="col-md-12">
                   <p class="copyright-text text-center">Copyright © <?= DATE('Y') ?> Jamia Urdu Aligarh . All rights reserved. Developed by Edtech Innovate Pvt. Ltd.</p>
                </div>
                <!--<div class="col-md-6 text-end d-none d-md-block">-->
                <!--   <div class="footer-links">-->
                <!--      <ul>-->
                <!--         <li><a href="#">Privacy Policy</a></li>-->
                <!--         <li><a href="#">Terms & Condition</a></li>-->
                <!--      </ul>-->
                <!--   </div>-->
                <!--</div>-->
             </div>
          </div>
       </div>
    </div>
 </footer>
 <div class="scroll-top">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
       <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
    </svg>
 </div>
 <script src="/website-assets/js/vendor/jquery-3.6.0.min.js" ></script>
  <script src="/website-assets/js/minfy-js/scripts.min.js" ></script>
<!-- <script src="/website-assets/js/app.min.js"></script>-->
<!-- <script src="/website-assets/js/main.js"></script>-->
<!-- <script src="jquery.min.js"></script>-->
<!--<script src="owlcarousel/owl.carousel.min.js"></script>-->
<!--<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>-->
<script>
   $(document).ready(function(){
      $(".owl-carousel").owlCarousel({
         items: 2, // Number of items to display
         loop: true, // Infinite loop
         autoplay: true, // Autoplay enabled
         autoplayTimeout: 3000, // Autoplay interval in milliseconds (adjust as needed)
         autoplayHoverPause: true, // Pause on hover
                 responsive: {
        0: {
          items: 1,
          nav: false,
        },
        680: {
          items: 2,
          nav: false,
          loop: false
        },}
      });
   });
   
       
        
</script>



<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "@id": "https://juaonline.in/#organization",
  "name": "Jamia Urdu Aligarh",
  "alternateName": [
    "JUA Online",
    "Jamia Urdu Aligarh Online"
  ],
  "url": "https://juaonline.in/",
  "logo": {
    "@type": "ImageObject",
    "url": "https://juaonline.in/website-assets/web/logo.png"
  },
  "image": "https://juaonline.in/website-assets/web/logo.png",
  "description": "Jamia Urdu Aligarh is a premier minority educational institution established in 1939, providing quality education through open and distance learning with a focus on women and marginalized communities.",
  "foundingDate": "1939",
  "founder": {
    "@type": "Organization",
    "name": "Jamia"
  },
  "email": "info@juaonline.in",
  "telephone": "+91-9818677522",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Dodhpur, Civil Lines",
    "addressLocality": "Aligarh",
    "addressRegion": "Uttar Pradesh",
    "postalCode": "202002",
    "addressCountry": "IN"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+91-9818677522",
    "contactType": "customer support",
    "email": "info@juaonline.in",
    "availableLanguage": "en-IN",
    "areaServed": "IN"
  },
  "sameAs": [
    "https://www.facebook.com/JamiaUrduUniversity",
    "https://www.instagram.com/jamia_urdu_online/",
    "https://www.linkedin.com/company/jamia-urdu-aligarh-online"
  ],
  "knowsAbout": [
    "Open Schooling",
    "Distance Education",
    "Secondary Education",
    "Senior Secondary Education",
    "Vocational Education",
    "Skill Development",
    "Urdu Education"
  ],
  "areaServed": {
    "@type": "Country",
    "name": "India"
  },
  "mainEntityOfPage": "https://juaonline.in/"
}
</script>

  <script async src="https://www.googletagmanager.com/gtag/js?id=G-761F02QQCJ"></script>
  <script>window.dataLayer = window.dataLayer || [];  function gtag(){dataLayer.push(arguments);}gtag('js', new Date()); gtag('config', 'G-761F02QQCJ');</script>
